#include <iostream>
#include <vector>
#include <algorithm>
#include "xcode_redirect.hpp"
//Project IDENTIFIER  = TUTOR14L
